import { pgTable, integer, jsonb, text, timestamp } from "drizzle-orm/pg-core";

// The published store catalog (products, prices, stock, shop info). A single row with id 1.
export const catalog = pgTable("catalog", {
  id: integer().primaryKey(),
  data: jsonb().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// The admin publish password (hashed). A single row with id 1, set on the first publish.
export const adminAuth = pgTable("admin_auth", {
  id: integer().primaryKey(),
  salt: text().notNull(),
  hash: text().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
