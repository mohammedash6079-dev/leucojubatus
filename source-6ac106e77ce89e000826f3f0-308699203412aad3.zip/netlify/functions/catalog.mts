import type { Config } from "@netlify/functions";
import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { adminAuth, catalog } from "../../db/schema.js";

const KEYS = ["products", "pid", "ship", "low", "coupons", "shop", "social", "pay"];

function hashPw(pw: string, salt: string) {
  return scryptSync(pw, salt, 32).toString("hex");
}

function pwMatches(pw: string, row: { salt: string; hash: string }) {
  const a = Buffer.from(hashPw(pw, row.salt), "hex");
  const b = Buffer.from(row.hash, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

async function setPassword(pw: string) {
  const salt = randomBytes(16).toString("hex");
  const values = { id: 1, salt, hash: hashPw(pw, salt), updatedAt: new Date() };
  await db.insert(adminAuth).values(values).onConflictDoUpdate({ target: adminAuth.id, set: values });
}

const err = (status: number, error: string) => Response.json({ error }, { status });

export default async (req: Request) => {
  if (req.method === "GET") {
    const [row] = await db.select().from(catalog).where(eq(catalog.id, 1));
    return Response.json(
      { data: row?.data ?? null, updatedAt: row?.updatedAt ?? null },
      { headers: { "Cache-Control": "no-store" } },
    );
  }

  if (req.method !== "PUT") return err(405, "Method not allowed");

  let body: any;
  try {
    body = await req.json();
  } catch {
    return err(400, "Invalid JSON");
  }
  const password = typeof body?.password === "string" ? body.password : "";
  if (password.length < 8) return err(401, "wrong_password");

  // The first successful publish sets the server password; later publishes must match it.
  const [auth] = await db.select().from(adminAuth).where(eq(adminAuth.id, 1));
  if (auth && !pwMatches(password, auth)) return err(401, "wrong_password");
  if (!auth) await setPassword(password);

  if (body.action === "password") {
    const next = typeof body.newPassword === "string" ? body.newPassword : "";
    if (next.length < 8) return err(400, "Use at least 8 characters");
    await setPassword(next);
    return Response.json({ ok: true });
  }

  const input = body.data;
  if (!input || typeof input !== "object" || !Array.isArray(input.products)) return err(400, "Missing products");
  const data: Record<string, unknown> = {};
  for (const k of KEYS) if (input[k] !== undefined) data[k] = input[k];

  const values = { id: 1, data, updatedAt: new Date() };
  await db.insert(catalog).values(values).onConflictDoUpdate({ target: catalog.id, set: values });
  return Response.json({ ok: true, updatedAt: values.updatedAt });
};

export const config: Config = {
  path: "/api/catalog",
};
