# LEUCO JUBATUS Store

The LEUCO JUBATUS online store: a single-page storefront with a shop, a cart, and an admin area. It also supports light and dark themes and can export PDFs (via jsPDF).

## Technologies
- One self-contained `index.html` (HTML, CSS, vanilla JavaScript)
- Product catalog embedded as JSON (`<script id="catalog">`)
- Browser `localStorage` for store state (`lj_store`) and view preference (`lj_view`)
- Netlify Function `/api/catalog` + Netlify Database for the published catalog that every visitor sees (admin presses **Publish to public**)
- Google Fonts (Michroma, Inter), jsPDF from cdnjs
- Hosted on Netlify as a static site

## Run locally
Open `index.html` in a browser, or run `netlify dev --port 8889`.

## Custom domain
Add the domain (for example `leucojubatus.com`) under **Domain management** in the Netlify project settings, then follow the DNS instructions Netlify shows you. Netlify provisions HTTPS automatically.

## Roadmap
- Move orders and customer data from `localStorage` to Netlify Database (the catalog is already shared)
- Protect the admin area with Netlify Identity
- Accept real payments (for example Stripe Checkout)
