# AGENTS.md

## Architecture
- Static site with no build step. `netlify.toml` publishes the repo root.
- `index.html` holds the whole app: styles, the embedded JSON catalog (`<script id="catalog" type="application/json">`), and the app script (views: shop, cart, admin).
- State is saved in `localStorage` (`lj_store`, `lj_view`). It is per-browser and not shared between visitors.

## Conventions
- Make targeted edits to `index.html`. Don't rewrite it, because the owner authored it and may re-upload newer versions.
- The original upload is in `.netlify/assets/`. `index.html` is the deployed copy.

## Non-obvious notes
- External dependencies are loaded from CDNs (Google Fonts, jsPDF on cdnjs).
- For shared persistence or auth, use Netlify Database and Netlify Identity (see the README roadmap).
